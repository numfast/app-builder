import sys, json, tempfile, zipfile, importlib.util
from pathlib import Path

# Self-extracting: this script runs from inside the .zip
_THIS = Path(__file__).resolve()
_ZIP = _THIS.parent / "calc-full-v1.0.0.zip"

# Load manifest
with zipfile.ZipFile(_ZIP) as zf:
    manifest = json.loads(zf.read("_manifest.json"))

# Register kernel
sys.path.insert(0, str(_ZIP.parent))

# Find and call entry point
from framework_builder import Builder
app = Builder.build(str(_THIS.parent / "calc/full.toml"))
if "start" in app.alias:
    app.alias["start"]()
else:
    print(f"App ready. Aliases: {list(app.alias.keys())}")
