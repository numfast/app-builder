from _lib.trig import trig_eval as _eval

eval_expr = _eval
