from _lib.ops import safe_eval as _eval

eval_expr = _eval
