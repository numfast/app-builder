from _lib.runner import run_tests as _run_all, collect_all as _collect

test = _run_all
test_all = _collect

def setup(kernel):
    import _lib.runner
    _lib.runner.kernel = kernel
