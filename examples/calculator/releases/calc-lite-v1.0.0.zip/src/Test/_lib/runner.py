kernel = None

def collect_all():
    """Collect tests from ALL extension metadata sections."""
    tests = []
    for section, meta in kernel.metadata.items():
        for name, tc in meta.get("tests", {}).items():
            tests.append((f"[{section}] {name}", tc["expr"], tc["expected"]))
    return tests

def run_tests():
    """Run all collected tests and print results."""
    all_tests = collect_all()
    if not all_tests:
        print("No tests found.")
        return

    passed = 0
    failed = 0
    print(f"Running {len(all_tests)} tests...")
    print()
    for label, expr, expected in all_tests:
        try:
            result = kernel.alias["eval_expr"](expr)
        except Exception as e:
            result = f"Error: {e}"
        if result == expected:
            passed += 1
        else:
            failed += 1
            print(f"  FAIL {label}: eval({expr!r}) = {result!r}, expected {expected!r}")
    print()
    print(f"Results: {passed} passed, {failed} failed, {len(all_tests)} total")
